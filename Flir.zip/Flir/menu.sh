#!/bin/sh

#xterm -e " xterm -e "cd /home/pi/Documents/Flir/ | python menu.py""

echo Iniciando interfaz...
cd /home/pi/Documents/Flir/
python menu.py

