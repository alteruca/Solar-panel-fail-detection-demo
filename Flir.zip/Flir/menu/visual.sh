#!/bin/sh

#xterm -e " xterm -e "cd /home/pi/Documents/Flir/ | python tkinter.py""

echo Iniciando programa...
cd /home/pi/Documents/Flir/menu/
python tkinter.py

